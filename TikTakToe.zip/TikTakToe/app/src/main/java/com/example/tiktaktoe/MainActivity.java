package com.example.tiktaktoe;

import androidx.appcompat.app.AppCompatActivity;

import android.nfc.cardemulation.OffHostApduService;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // 0 = yellow 1 = red
 int activePlayer = 0;
 int YellowplayerScore = 0;
 int redplayerScore = 0;
 int gameState[] = {2,2,2,2,2,2,2,2,2};
 int [] [] winningPositions = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};
 Boolean gameActive = true;

    public  void dropIn(View view)
    {

        ImageView counter = (ImageView) view;

        int tappedCounter = Integer.parseInt(counter.getTag().toString());

        if (gameState[tappedCounter] == 2 && gameActive) {
            counter.setTranslationY(-1500);
            gameState[tappedCounter] = activePlayer;

            if (activePlayer == 0) {
                counter.setImageResource(R.drawable.yellow);
                activePlayer = 1;
            } else {
                counter.setImageResource(R.drawable.red);
                activePlayer = 0;
            }
            Boolean gameStateBool = false;

            for (int[] winningPosition : winningPositions)
            {
                Log.i("ActivePlayer", "Winning postion:"+  String.valueOf(gameState[winningPosition[0]]) + ", "+  String.valueOf(gameState[winningPosition[1]]) + ","+  String.valueOf(gameState[winningPosition[2]])  );

                if (gameState[winningPosition[0]] == gameState[winningPosition[1]] && gameState[winningPosition[1]] == gameState[winningPosition[2]] && gameState[winningPosition[0]] != 2 )
                {
// Someone has been win
                    gameStateBool = true;
                    gameActive = false;
                    String Winner = "";
if (activePlayer == 1 )
{
    Winner = "Yellow";
    TextView textView = (TextView) findViewById(R.id.textView);
    YellowplayerScore = YellowplayerScore + 1;
    textView.setText("Yellow Player: "+ YellowplayerScore +"Points");

}
   else
{
    Winner = "Red";
    TextView textView = (TextView) findViewById(R.id.textView2);

    redplayerScore = redplayerScore + 1;
    textView.setText("Red Player: "+ redplayerScore +"Points");

}
                    Button reStartButton = (Button) findViewById(R.id.restartButton);
                    reStartButton.setText("ReStart");
                    reStartButton.setVisibility(View.VISIBLE);
                    Toast.makeText(this, "Congrat Player " + Winner + " win!!", Toast.LENGTH_SHORT).show();
                }
                else
                {



                }
            }


            counter.animate().translationYBy(1500).rotation(3600).setDuration(300);


            for (int i = 0 ; i < gameState.length; i++ )
            {
                if (gameState[i] == 2)
                {
                    gameStateBool = true;
                    Log.i("INdex","Call Bool");
                }
            }

            if (gameStateBool == false)
            {
                Button reStartButton = (Button) findViewById(R.id.restartButton);
                reStartButton.setText("ReStart");
                reStartButton.setVisibility(View.VISIBLE);
                Toast.makeText(this, "Match Draw", Toast.LENGTH_SHORT).show();
            }

        }
        else
        {

        }
    }
  public  void reStartAction(View view)
  {
      Button reStartButton = (Button) findViewById(R.id.restartButton);
      reStartButton.setVisibility(View.INVISIBLE);
      ImageView counter = (ImageView) findViewById(R.id.imageView1);
      ImageView counter2 = (ImageView) findViewById(R.id.imageView2);
      ImageView counter3 = (ImageView) findViewById(R.id.imageView3);
      ImageView counter4 = (ImageView) findViewById(R.id.imageView4);
      ImageView counter5 = (ImageView) findViewById(R.id.imageView5);
      ImageView counter6 = (ImageView) findViewById(R.id.imageView6);
      ImageView counter7 = (ImageView) findViewById(R.id.imageView7);
      ImageView counter8 = (ImageView) findViewById(R.id.imageView8);
      ImageView counter9 = (ImageView) findViewById(R.id.imageView9);

      counter.setImageDrawable(null);
      counter2.setImageDrawable(null);
      counter3.setImageDrawable(null);
      counter4.setImageDrawable(null);
      counter5.setImageDrawable(null);
      counter6.setImageDrawable(null);
      counter7.setImageDrawable(null);
      counter8.setImageDrawable(null);
      counter9.setImageDrawable(null);

      for (int i = 0 ; i < gameState.length; i++ )
      {
          gameState[i] = 2;

      }
      activePlayer = 0;
      gameActive = true;
  }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}